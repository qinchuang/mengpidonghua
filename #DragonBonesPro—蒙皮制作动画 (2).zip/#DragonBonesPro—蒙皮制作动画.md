#         #DragonBonesPro—蒙皮制作动画 
本文，我们通过DragonBonesPro实现一个足球上下跳动的动画效果。该动画包括足球，阴影。下面我们就具体的来说一下怎么来实现这样的一个动画。

**首先我们要准备游戏需要的图片**
![enter image description here](https://t1.picb.cc/uploads/2019/02/12/VMNQhe.png)
把准备好的图片拖到资源量里。 在骨架装配了创建两个骨骼 。![enter image description here](http://f.hiphotos.baidu.com/image/pic/item/359b033b5bb5c9eac0544324d839b6003bf3b356.jpg)
接下来点击图片，显示插槽，勾选网格，绑定骨头。
![enter image description here]
(http://c.hiphotos.baidu.com/image/pic/item/962bd40735fae6cd2174e2a602b30f2443a70f30.jpg)
点击编辑网格按钮，选择手动绘制边线工具，沿图片边缘绘制点。![enter image description here](http://a.hiphotos.baidu.com/image/pic/item/b90e7bec54e736d1df853dcf96504fc2d4626967.jpg)
选择动画制作，选择自动关键帧，分别在0—6—12—18—24， 添加关键帧![enter image description here](http://h.hiphotos.baidu.com/image/pic/item/83025aafa40f4bfbacf525930e4f78f0f63618cb.jpg)
0帧到6帧是球有个向上弹变形的过程，6帧到18帧球慢慢的恢复原形，18帧时球弹到最高，过来18帧，球由于受重力影响，往下降。
![enter image description here](http://d.hiphotos.baidu.com/image/pic/item/d000baa1cd11728b5c3327e5c5fcc3cec2fd2cde.jpg)
球是最终作品展示
![enter image description here](http://h.hiphotos.baidu.com/image/pic/item/96dda144ad3459820db7725501f431adcbef843c.jpg)

通过本片文字，你可以学会蒙皮的使用。
![Alt text](./NewProject_ske.json)

![Alt text](./NewProject_tex.json)

